#ifndef __CIAGI_H__
#define __CIAGI_H__

int* automatycznyGenerator(int n, const int max_sum_odd);
bool isEven(int i);
int* generatorZakres(int n, int a1, int an);

#endif