#include <cstdlib>
#include <iostream>
#include <ctime>
#include <algorithm>
#include "Ciagi.h"

using namespace std;
/*Program podaje oddzielnie sum� liczb parzystych i nieparzystych z ci�gu*/
int main(int argc, char *argv[])
{
    //int ciag[];
    int sumEven=0;
    int sumOdd=0;
    int i=0;
	int n;
   
	cout<<"Program sprawdza:\n-czy suma elemetow nieparzystych jest <=100\n-podaje najmniejszy dodatni element ciagu\n\nIstnieje mozliwosc wyboru sposobu generowania liczb ciagu.\n\n";
	cout<<"Pdaj liczbe elementow ciag: ";
    cin>>n;
    int* ciag; //deklaracja tworzenia tablicy ,wskaznik na pierwszy element tablicy

      
	//----------------wypelnianie tablicy liczbami
     int wybor; //wybor sposobu generowania danych
	 cout<<"Wybierz sposob generowania elementow ciagu:\n";
     cout<<"automatyczne-1, pseudolosowe - 2; klawiatura-3\n";
     cin>>wybor;
     
     switch(wybor)
     {
		case 1: //automatyczne generowanie ci�gu
		{
			cout<<"Podaj liczbe elementow ciagu\n";
			cin>>n;
			ciag = automatycznyGenerator(n, 100);
			break;
		}

		case 2://generator liczb pseudolosowych
		{
			int a1;
			int an;
			cout<<"Podaj dolny zakres ciagu:\n";
			cin>>a1;
			cout<<"Podaj gorny zakres ciagu:\n\n";
			cin>>an;
			
			ciag= new int[n];

			for(int i=0; i<n;i++)
			{
				
				ciag[i]=a1+(rand()%(an-a1));
				cout<<ciag[i]<<endl;
			}        
			break;   
		}
		case 3://wpisywanie z klawiatury
			ciag= new int[n];
			for( int i=0; i<n; i++) 
			{
				printf("wpisz el. o indeksie %d: ",i);
				scanf("%lf",&(ciag[i]));
				printf("\tciag[%d]=%lf\n",i,ciag[i]); 
			}
			break;
     }

	 cout<<"wypisuje elementy ciagu\n";
	 for(int i =0; i<n;i++)
	 {
		 cout<<ciag[i]<<endl;
	 }
	 cout<<"koniec wypisywania\n";
		 
	//	 najmniejszy element ci�gu
	int min =  numeric_limits<int>::max(); //mks wartosc jaka zmiesi sie w tblicy typu int
	int numerElementuMin=0;
	for(int i=0;i<n;i++)
	{
		if((min>ciag[i])/*&&(ciag[i]>0)*/)
		{
			min=ciag[i];
			numerElementuMin=i;
		}
	}    
	cout<<"Wartosc minimalnego elementu to= "<<min<<endl
		<<"Jest to "<<numerElementuMin<<"-ty element tablicy (ciag["<<numerElementuMin<<"])"<<endl<<endl<<endl;



	 /*

	//-----------------------------------------
    cout<<"Podaj pierwsza i ostatnia wartosc z przedzialu:"<<endl;
    cin>>a1>>an;
    cout<<endl;
    
    bool currEven; //okresla wartosc current even jako prawda lub fa�sz
    if(ciag[0]%2==0) currEven = true;
    else currEven = false;
    
    
    for(i = 0;ciag[i]<=ciag[.......];i++)
    {
        if(currEven)
        {
            //Dla parzystych
            sumEven+=ciag[i]; //sumEven = sumEven+i
        }
        else
        {
            //Dla nieparzystych
            sumOdd+=ciag[i];
        }
        currEven = !currEven;
       
    }
    
	if(sumOdd<=100)
	    cout<<"suma liczb nieparzystych jest niewieksza od 100 i wynosi: "<<sumEven<<endl;
	else
		cout<<"suma liczb nieparzystych jest wieksza od 100 i wynosi: "<<sumEven<<endl;
		*/

	delete[] ciag; //kasowanie tablicy dynamicznej

	system("PAUSE");
    return EXIT_SUCCESS;
}
